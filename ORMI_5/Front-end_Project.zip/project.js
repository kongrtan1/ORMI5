var open = document.querySelector('.open-modal-btn');

var close = document.querySelector('.close-btn');

var layout = document.querySelector('.modal');

console.log(open);

console.log(layout);

open.addEventListener('click', function () {
  layout.style.display = 'flex';
});

close.addEventListener('click', function () {
  layout.style.display = 'none';
});
